package com.aidata.springboard2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboard2Application {

    public static void main(String[] args) {
        SpringApplication.run(Springboard2Application.class, args);
    }

}
